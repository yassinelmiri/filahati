'use client';

import { useState, useMemo } from 'react';
import { useApp } from '@/lib/store';
import { Feed } from '@/lib/feed-data';
import {
  CowCharacteristics,
  calculateNutrientNeeds,
  calculateIngestionCapacity,
  calculateRation,
  calculateMineralSupplement,
  NutrientNeeds,
  IngestionCapacity,
  RationResult
} from '@/lib/calculations';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { FieldGroup, Field, FieldLabel } from '@/components/ui/field';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Calculator,
  Beef,
  FlaskConical,
  Save,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Info,
  ChevronRight
} from 'lucide-react';
import { cn } from '@/lib/utils';

export function CalculatorView() {
  const { t, feeds, language, incrementCalculations, saveRation } = useApp();

  // Cow characteristics state
  const [cowData, setCowData] = useState<CowCharacteristics>({
    liveWeight: 650,
    milkProductionPotential: 30,
    lactationWeek: 16,
    bodyConditionScore: 2.5,
    ageMonths: 44,
    gestationWeek: 0,
    isMultiparous: true
  });

  // Selected feeds
  const [selectedForage, setSelectedForage] = useState<string>('1'); // Corn silage
  const [selectedConcentrate, setSelectedConcentrate] = useState<string>('12'); // Soybean meal 44
  const [forageQuantity, setForageQuantity] = useState<number | undefined>(undefined);

  // Results
  const [hasCalculated, setHasCalculated] = useState(false);
  const [isSaveDialogOpen, setIsSaveDialogOpen] = useState(false);
  const [rationName, setRationName] = useState('');

  // Get feed objects
  const forages = feeds.filter(f => f.category === 'forage');
  const concentrates = feeds.filter(f => f.category === 'concentrate');
  const forage = feeds.find(f => f.id === selectedForage);
  const concentrate = feeds.find(f => f.id === selectedConcentrate);

  // Calculate results
  const results = useMemo(() => {
    if (!forage || !concentrate) return null;

    const needs = calculateNutrientNeeds(cowData);
    const ci = calculateIngestionCapacity(cowData);
    const ration = calculateRation(cowData, forage, concentrate, forageQuantity);
    const mineral = calculateMineralSupplement(
      ration.caSupply,
      ration.pSupply,
      needs.caAbs,
      needs.pAbs
    );

    return { needs, ci, ration, mineral };
  }, [cowData, forage, concentrate, forageQuantity]);

  const handleCalculate = () => {
    setHasCalculated(true);
    incrementCalculations();
  };

  const handleReset = () => {
    setCowData({
      liveWeight: 650,
      milkProductionPotential: 30,
      lactationWeek: 16,
      bodyConditionScore: 2.5,
      ageMonths: 44,
      gestationWeek: 0,
      isMultiparous: true
    });
    setSelectedForage('1');
    setSelectedConcentrate('12');
    setForageQuantity(undefined);
    setHasCalculated(false);
  };

  const handleSave = () => {
    if (results && rationName.trim()) {
      saveRation({
        name: rationName,
        cowCharacteristics: cowData,
        feeds: [
          { feedId: selectedForage, quantity: results.ration.forageDM },
          { feedId: selectedConcentrate, quantity: results.ration.concentrateDM }
        ],
        results: {
          uflSupply: results.ration.uflSupply,
          pdinSupply: results.ration.pdinSupply,
          pdieSupply: results.ration.pdieSupply,
          milkPermitted: Math.min(
            results.ration.milkPermittedByUFL,
            results.ration.milkPermittedByPDIN,
            results.ration.milkPermittedByPDIE
          )
        }
      });
      setIsSaveDialogOpen(false);
      setRationName('');
    }
  };

  const getFeedName = (feed: Feed) => {
    return language === 'ar' ? feed.nameAr : feed.nameFr;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">{t('calculator')}</h1>
          <p className="text-muted-foreground">
            {language === 'fr'
              ? 'Calculateur de ration selon le système INRA 2007'
              : 'حاسبة الحصة وفق نظام INRA 2007'}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleReset}>
            <RotateCcw className="w-4 h-4 mr-2" />
            {t('reset')}
          </Button>
          {hasCalculated && results && (
            <Button onClick={() => setIsSaveDialogOpen(true)}>
              <Save className="w-4 h-4 mr-2" />
              {t('save')}
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Input panel */}
        <div className="space-y-6">
          {/* Cow characteristics */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Beef className="w-5 h-5 text-primary" />
                {t('cowCharacteristics')}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <FieldGroup>
                <div className="grid grid-cols-2 gap-4">
                  <Field>
                    <FieldLabel>{t('liveWeight')}</FieldLabel>
                    <Input
                      type="number"
                      value={cowData.liveWeight}
                      onChange={(e) => setCowData({ ...cowData, liveWeight: parseFloat(e.target.value) || 0 })}
                    />
                  </Field>
                  <Field>
                    <FieldLabel>{t('milkProduction')}</FieldLabel>
                    <Input
                      type="number"
                      value={cowData.milkProductionPotential}
                      onChange={(e) => setCowData({ ...cowData, milkProductionPotential: parseFloat(e.target.value) || 0 })}
                    />
                  </Field>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <Field>
                    <FieldLabel>{t('lactationWeek')}</FieldLabel>
                    <Input
                      type="number"
                      value={cowData.lactationWeek}
                      onChange={(e) => setCowData({ ...cowData, lactationWeek: parseInt(e.target.value) || 0 })}
                    />
                  </Field>
                  <Field>
                    <FieldLabel>{t('age')}</FieldLabel>
                    <Input
                      type="number"
                      value={cowData.ageMonths}
                      onChange={(e) => setCowData({ ...cowData, ageMonths: parseInt(e.target.value) || 0 })}
                    />
                  </Field>
                </div>

                <Field>
                  <FieldLabel>{t('bodyConditionScore')} ({cowData.bodyConditionScore})</FieldLabel>
                  <Slider
                    value={[cowData.bodyConditionScore]}
                    onValueChange={([value]) => setCowData({ ...cowData, bodyConditionScore: value })}
                    min={1}
                    max={5}
                    step={0.5}
                    className="mt-2"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground mt-1">
                    <span>1</span>
                    <span>5</span>
                  </div>
                </Field>

                <div className="grid grid-cols-2 gap-4">
                  <Field>
                    <FieldLabel>{t('gestationWeek')}</FieldLabel>
                    <Input
                      type="number"
                      value={cowData.gestationWeek}
                      onChange={(e) => setCowData({ ...cowData, gestationWeek: parseInt(e.target.value) || 0 })}
                    />
                  </Field>
                  <Field>
                    <FieldLabel>{t('parity')}</FieldLabel>
                    <Select
                      value={cowData.isMultiparous ? 'multi' : 'primi'}
                      onValueChange={(v) => setCowData({ ...cowData, isMultiparous: v === 'multi' })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="primi">{t('primiparous')}</SelectItem>
                        <SelectItem value="multi">{t('multiparous')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                </div>
              </FieldGroup>
            </CardContent>
          </Card>

          {/* Feed selection */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FlaskConical className="w-5 h-5 text-primary" />
                {t('feeds')}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Field>
                <FieldLabel>{t('forage')}</FieldLabel>
                <Select value={selectedForage} onValueChange={setSelectedForage}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {forages.map((feed) => (
                      <SelectItem key={feed.id} value={feed.id}>
                        {getFeedName(feed)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>

              <Field>
                <FieldLabel>{t('concentrate')}</FieldLabel>
                <Select value={selectedConcentrate} onValueChange={setSelectedConcentrate}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {concentrates.map((feed) => (
                      <SelectItem key={feed.id} value={feed.id}>
                        {getFeedName(feed)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>

              <Field>
                <FieldLabel>
                  {language === 'fr' ? 'Quantité fourrage fixe (kg MS)' : 'كمية العلف الثابتة (كجم مج)'} ({language === 'fr' ? 'optionnel' : 'اختياري'})
                </FieldLabel>
                <Input
                  type="number"
                  placeholder={language === 'fr' ? 'Automatique si vide' : 'تلقائي إذا فارغ'}
                  value={forageQuantity ?? ''}
                  onChange={(e) => setForageQuantity(e.target.value ? parseFloat(e.target.value) : undefined)}
                />
              </Field>

              <Button onClick={handleCalculate} className="w-full">
                <Calculator className="w-4 h-4 mr-2" />
                {t('calculate')}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Results panel */}
        <div className="space-y-6">
          {hasCalculated && results ? (
            <>
              {/* Summary card */}
              <Card className={cn(
                "border-2",
                results.ration.isBalanced ? "border-success/50 bg-success/5" : "border-warning/50 bg-warning/5"
              )}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        {results.ration.isBalanced ? (
                          <CheckCircle2 className="w-6 h-6 text-success" />
                        ) : (
                          <XCircle className="w-6 h-6 text-warning" />
                        )}
                        <h3 className="text-lg font-semibold">
                          {t('rationBalance')}
                        </h3>
                      </div>
                      <Badge className={cn(
                        "mt-2",
                        results.ration.isBalanced 
                          ? "bg-success/10 text-success border-success/20" 
                          : "bg-warning/10 text-warning border-warning/20"
                      )} variant="outline">
                        {results.ration.isBalanced ? t('balanced') : t('unbalanced')}
                      </Badge>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">
                        {language === 'fr' ? 'Production lait permise' : 'إنتاج الحليب المسموح'}
                      </p>
                      <p className="text-3xl font-bold text-foreground">
                        {Math.min(
                          results.ration.milkPermittedByUFL,
                          results.ration.milkPermittedByPDIN,
                          results.ration.milkPermittedByPDIE
                        ).toFixed(1)}
                      </p>
                      <p className="text-sm text-muted-foreground">{t('kgPerDay')}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Detailed results tabs */}
              <Tabs defaultValue="needs" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="needs">
                    {language === 'fr' ? 'Besoins' : 'الاحتياجات'}
                  </TabsTrigger>
                  <TabsTrigger value="ci">CI</TabsTrigger>
                  <TabsTrigger value="ration">
                    {language === 'fr' ? 'Ration' : 'الحصة'}
                  </TabsTrigger>
                  <TabsTrigger value="mineral">
                    {language === 'fr' ? 'Minéraux' : 'المعادن'}
                  </TabsTrigger>
                </TabsList>

                {/* Needs tab */}
                <TabsContent value="needs">
                  <Card className="border-border/50">
                    <CardHeader>
                      <CardTitle>{t('totalNeeds')}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <ResultRow
                        label={t('energyNeeds')}
                        value={results.needs.uflTotal.toFixed(2)}
                        unit="UFL/j"
                        breakdown={[
                          { label: t('maintenanceNeeds'), value: results.needs.uflMaintenance.toFixed(2) },
                          { label: t('productionNeeds'), value: results.needs.uflProduction.toFixed(2) },
                          { label: t('gestationNeeds'), value: results.needs.uflGestation.toFixed(2) },
                        ]}
                      />
                      <ResultRow
                        label={t('proteinNeeds')}
                        value={results.needs.pdiTotal.toFixed(0)}
                        unit="g PDI/j"
                        breakdown={[
                          { label: t('maintenanceNeeds'), value: results.needs.pdiMaintenance.toFixed(0) },
                          { label: t('productionNeeds'), value: results.needs.pdiProduction.toFixed(0) },
                          { label: t('gestationNeeds'), value: results.needs.pdiGestation.toFixed(0) },
                        ]}
                      />
                      <ResultRow
                        label={t('calciumNeeds')}
                        value={results.needs.caAbs.toFixed(1)}
                        unit="g Ca abs/j"
                      />
                      <ResultRow
                        label={t('phosphorusNeeds')}
                        value={results.needs.pAbs.toFixed(1)}
                        unit="g P abs/j"
                      />
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* CI tab */}
                <TabsContent value="ci">
                  <Card className="border-border/50">
                    <CardHeader>
                      <CardTitle>{t('ingestionCapacity')}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="text-center p-4 bg-primary/5 rounded-lg">
                        <p className="text-sm text-muted-foreground">CI</p>
                        <p className="text-4xl font-bold text-primary">{results.ci.ci.toFixed(2)}</p>
                        <p className="text-sm text-muted-foreground">UEL</p>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between py-2 border-b border-border">
                          <span className="text-muted-foreground">{language === 'fr' ? 'CI base (poids)' : 'CI أساسي (الوزن)'}</span>
                          <span className="font-medium">{results.ci.baseCI.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between py-2 border-b border-border">
                          <span className="text-muted-foreground">{language === 'fr' ? 'Effet production' : 'تأثير الإنتاج'}</span>
                          <span className="font-medium">+{results.ci.productionEffect.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between py-2 border-b border-border">
                          <span className="text-muted-foreground">{language === 'fr' ? 'Effet NEC' : 'تأثير NEC'}</span>
                          <span className="font-medium">{results.ci.necEffect >= 0 ? '+' : ''}{results.ci.necEffect.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between py-2 border-b border-border">
                          <span className="text-muted-foreground">{language === 'fr' ? 'Coef. lactation' : 'معامل الحلب'}</span>
                          <span className="font-medium">x {results.ci.lactationEffect.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between py-2 border-b border-border">
                          <span className="text-muted-foreground">{language === 'fr' ? 'Coef. parité' : 'معامل عدد الولادات'}</span>
                          <span className="font-medium">x {results.ci.parityEffect.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between py-2">
                          <span className="text-muted-foreground">{language === 'fr' ? 'Coef. maturité' : 'معامل النضج'}</span>
                          <span className="font-medium">x {results.ci.maturityEffect.toFixed(2)}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Ration tab */}
                <TabsContent value="ration">
                  <Card className="border-border/50">
                    <CardHeader>
                      <CardTitle>{language === 'fr' ? 'Composition de la ration' : 'تركيبة الحصة'}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Quantities */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 bg-chart-1/10 rounded-lg text-center">
                          <p className="text-sm text-muted-foreground">{t('forage')}</p>
                          <p className="text-2xl font-bold text-chart-1">
                            {results.ration.forageDM.toFixed(2)}
                          </p>
                          <p className="text-xs text-muted-foreground">kg MS</p>
                        </div>
                        <div className="p-4 bg-chart-2/10 rounded-lg text-center">
                          <p className="text-sm text-muted-foreground">{t('concentrate')}</p>
                          <p className="text-2xl font-bold text-chart-2">
                            {results.ration.concentrateDM.toFixed(2)}
                          </p>
                          <p className="text-xs text-muted-foreground">kg MS</p>
                        </div>
                      </div>

                      {/* Parameters */}
                      <div className="space-y-3">
                        <div className="flex justify-between items-center py-2 border-b border-border">
                          <span className="text-sm text-muted-foreground">E (correction)</span>
                          <span className="font-medium">{results.ration.E.toFixed(3)} UFL</span>
                        </div>
                        <div className="flex justify-between items-center py-2 border-b border-border">
                          <span className="text-sm text-muted-foreground">Sg (substitution)</span>
                          <span className="font-medium">{results.ration.Sg.toFixed(3)}</span>
                        </div>
                        <div className="flex justify-between items-center py-2 border-b border-border">
                          <span className="text-sm text-muted-foreground">% Concentré</span>
                          <span className="font-medium">{results.ration.concentratePercentage.toFixed(1)}%</span>
                        </div>
                        <div className="flex justify-between items-center py-2 border-b border-border">
                          <span className="text-sm text-muted-foreground">Rmic (PDIN-PDIE)/UFL</span>
                          <span className={cn(
                            "font-medium",
                            results.ration.rmic >= -4 ? "text-success" : "text-warning"
                          )}>
                            {results.ration.rmic.toFixed(2)}
                          </span>
                        </div>
                      </div>

                      {/* Milk permitted breakdown */}
                      <div className="space-y-2">
                        <p className="text-sm font-medium">{language === 'fr' ? 'Lait permis par nutriment' : 'الحليب المسموح به حسب المغذيات'}</p>
                        <div className="space-y-2">
                          <ProgressBar
                            label="UFL"
                            value={results.ration.milkPermittedByUFL}
                            max={cowData.milkProductionPotential * 1.2}
                            target={cowData.milkProductionPotential}
                          />
                          <ProgressBar
                            label="PDIN"
                            value={results.ration.milkPermittedByPDIN}
                            max={cowData.milkProductionPotential * 1.2}
                            target={cowData.milkProductionPotential}
                          />
                          <ProgressBar
                            label="PDIE"
                            value={results.ration.milkPermittedByPDIE}
                            max={cowData.milkProductionPotential * 1.2}
                            target={cowData.milkProductionPotential}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                {/* Mineral tab */}
                <TabsContent value="mineral">
                  <Card className="border-border/50">
                    <CardHeader>
                      <CardTitle>{language === 'fr' ? 'Équilibre minéral' : 'التوازن المعدني'}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 bg-muted/50 rounded-lg text-center">
                          <p className="text-sm text-muted-foreground">{language === 'fr' ? 'Déficit Ca' : 'عجز Ca'}</p>
                          <p className="text-xl font-bold">{results.mineral.caDeficit.toFixed(1)} g</p>
                        </div>
                        <div className="p-4 bg-muted/50 rounded-lg text-center">
                          <p className="text-sm text-muted-foreground">{language === 'fr' ? 'Déficit P' : 'عجز P'}</p>
                          <p className="text-xl font-bold">{results.mineral.pDeficit.toFixed(1)} g</p>
                        </div>
                      </div>

                      {results.mineral.amv && (
                        <div className="p-4 bg-primary/5 rounded-lg">
                          <p className="text-sm font-medium mb-2">{language === 'fr' ? 'AMV recommandé' : 'AMV الموصى به'}</p>
                          <div className="flex justify-between items-center">
                            <span>{results.mineral.amv.nameFr}</span>
                            <span className="font-bold">{results.mineral.amvQuantity} g</span>
                          </div>
                        </div>
                      )}

                      {results.mineral.caco3Quantity > 0 && (
                        <div className="p-4 bg-secondary/50 rounded-lg">
                          <p className="text-sm font-medium mb-2">CaCO3</p>
                          <div className="flex justify-between items-center">
                            <span>{language === 'fr' ? 'Carbonate de calcium' : 'كربونات الكالسيوم'}</span>
                            <span className="font-bold">{results.mineral.caco3Quantity} g</span>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </>
          ) : (
            <Card className="border-border/50 h-96 flex items-center justify-center">
              <div className="text-center text-muted-foreground">
                <Calculator className="w-16 h-16 mx-auto mb-4 opacity-30" />
                <p className="text-lg font-medium">
                  {language === 'fr' 
                    ? 'Configurez les paramètres et cliquez sur Calculer'
                    : 'قم بتكوين المعلمات واضغط على حساب'}
                </p>
              </div>
            </Card>
          )}
        </div>
      </div>

      {/* Save dialog */}
      <Dialog open={isSaveDialogOpen} onOpenChange={setIsSaveDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('save')}</DialogTitle>
          </DialogHeader>
          <Field>
            <FieldLabel>{language === 'fr' ? 'Nom de la ration' : 'اسم الحصة'}</FieldLabel>
            <Input
              value={rationName}
              onChange={(e) => setRationName(e.target.value)}
              placeholder={language === 'fr' ? 'Ma ration...' : 'حصتي...'}
            />
          </Field>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsSaveDialogOpen(false)}>
              {t('cancel')}
            </Button>
            <Button onClick={handleSave} disabled={!rationName.trim()}>
              {t('save')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Helper components
function ResultRow({ 
  label, 
  value, 
  unit, 
  breakdown 
}: { 
  label: string; 
  value: string; 
  unit: string;
  breakdown?: { label: string; value: string }[];
}) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="border-b border-border pb-3">
      <div 
        className={cn(
          "flex justify-between items-center",
          breakdown && "cursor-pointer"
        )}
        onClick={() => breakdown && setExpanded(!expanded)}
      >
        <div className="flex items-center gap-2">
          {breakdown && (
            <ChevronRight className={cn(
              "w-4 h-4 transition-transform",
              expanded && "rotate-90"
            )} />
          )}
          <span className="text-sm text-muted-foreground">{label}</span>
        </div>
        <span className="font-medium">{value} <span className="text-muted-foreground text-xs">{unit}</span></span>
      </div>
      {breakdown && expanded && (
        <div className="mt-2 ml-6 space-y-1">
          {breakdown.map((item, idx) => (
            <div key={idx} className="flex justify-between text-xs text-muted-foreground">
              <span>{item.label}</span>
              <span>{item.value}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ProgressBar({ 
  label, 
  value, 
  max, 
  target 
}: { 
  label: string; 
  value: number; 
  max: number;
  target: number;
}) {
  const percentage = (value / max) * 100;
  const targetPercentage = (target / max) * 100;
  const isAboveTarget = value >= target;

  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs">
        <span className="text-muted-foreground">{label}</span>
        <span className={cn(
          "font-medium",
          isAboveTarget ? "text-success" : "text-warning"
        )}>
          {value.toFixed(1)} kg
        </span>
      </div>
      <div className="relative h-2 bg-muted rounded-full overflow-hidden">
        <div 
          className={cn(
            "absolute h-full rounded-full transition-all",
            isAboveTarget ? "bg-success" : "bg-warning"
          )}
          style={{ width: `${Math.min(percentage, 100)}%` }}
        />
        <div 
          className="absolute h-full w-0.5 bg-foreground/50"
          style={{ left: `${targetPercentage}%` }}
        />
      </div>
    </div>
  );
}
